function updateReeks() {
    const reeksID = $('#reeksID').val()
    const nieuweReeks = $('#nieuweReeks').val()

    $.ajax({
        url:'./includes/reeks-update.php',
        method:'POST',
        data:{
            reeksID,
            nieuweReeks
        },
        dataType:'json',
        success: function () {
            console.log('yeah');
            $('#succesMessageReeks').css({'display':'block'})
            $('#succesMessageReeks').html('Reeks geupdate!')
            //setTimeout(function() {
            //    location.reload(); 
            //}, 3000);
        }

    })
}
function updateLopers() {
    const nieuweFirstname = $('#nieuweFirstname').val();
    const nieuweLastname = $('#nieuweLastname').val();
    const nieuweGender = $('#nieuweGender').val();
    const nieuweBirthdate = $('#nieuweBirthdate').val();
    const klasID = $('#klasID').val();
    const schoolID = $('#schoolID').val();
    const reeksID = $('#reeksID').val();
    const loperID= $('#loperID').val();


    $.ajax({
        url:'./includes/lopers-update.php',
        method:'POST',
        data:{
            nieuweFirstname,
            nieuweLastname,
            nieuweGender,
            nieuweBirthdate,
            klasID,
            schoolID,
            reeksID,
            loperID
        },  
        dataType:'json',
        success: function () {
            console.log('yeah');
            $('#succesMessageLoper').css({'display':'block'})
            $('#succesMessageLoper').html('Loper geupdate!')
           // setTimeout(function() {
           //     location.reload();  
           // }, 3000);
        }

    })
}
function fetchLoperData() {
    var loperID = $('#loperID').val();
    if (loperID) {
        $.ajax({
            url: './includes/fetch_loper_data.php',
            method: 'GET',
            data: { id: loperID },
            dataType: 'json',
            success: function(data) {
                $('#nieuweFirstname').val(data.firstname);
                $('#nieuweLastname').val(data.lastname);
                $('#nieuweGender').val(data.gender);
                $('#nieuweBirthdate').val(data.birthdate);
                $('#schoolID').val(data.schoolID);
                $('#klasID').val(data.klasID);
                $('#reeksID').val(data.reeksID);
            },
        });
    }
}





    