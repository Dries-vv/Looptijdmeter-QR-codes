  <?php
  session_start();
  ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <title>Cross der jongeren</title>
</head>


<body>
  <?php
  include './header.php';
  ?>

  <div class="container">
    <div class="content">
            <div class="welcome-box">
                <h1>Welkom bij de cross der jongeren!</h1>
                <p>Om toegang te krijgen tot alle functies, moet je inloggen.</p>
            </div>
        </div>
  </div>
</body>

<style>
    .container {
        text-align: center;
        margin-top: 20px;
    }
    .welcome-box {
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        margin-top: 20px;
    }
</style>

</html>