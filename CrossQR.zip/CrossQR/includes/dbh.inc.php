<?php
$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'cross_qr';

$conn = mysqli_connect($hostname,$username,$password,$database );

function generateUUIDv4() {
    // Genereer 16 bytes willekeurige gegevens
    $data = random_bytes(16);
    // Zet de versiebits (bits 6 en 7) van de 7e byte op 0100 (versie 4)
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    // Zet de reserveringsbits (bits 4 en 5) van de 9e byte op 10
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    // Zet de resulterende bytes om in een UUID-string
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}
?>      