<?php
include "./dbh.inc.php";
$response = array();


$nieuweFirstname = $_POST['nieuweFirstname'];
$nieuweLastname = $_POST['nieuweLastname'];
$nieuweGender = $_POST['nieuweGender'];
$nieuweBirthdate = $_POST['nieuweBirthdate'];
$klasID = $_POST['klasID'];
$schoolID = $_POST['schoolID'];
$reeksID = $_POST['reeksID'];
$loperID = $_POST['loperID'];


$sql = "UPDATE `lopers` SET `firstname` = ?,`lastname` = ?,`gender` = ?,`birthdate` = ?,`klasID` = ?,`schoolID` = ?,`reeksID` = ? WHERE `id` = ?";
$statement = $conn->prepare($sql);
$statement->bind_param('ssssssss', $nieuweFirstname, $nieuweLastname, $nieuweGender, $nieuweBirthdate, $klasID, $schoolID, $reeksID, $loperID);
$statement->execute();

echo json_encode($response);


//reeks id word 

?>