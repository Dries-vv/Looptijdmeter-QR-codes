<?php
include "./dbh.inc.php";
$response = array();
$html = "";

$reeksID = $_POST['reeksID'];
$sql = "SELECT l.id, l.firstname, l.lastname, l.finishTime, r.startAt 
FROM `lopers` l
INNER JOIN `reeksen` r ON l.reeksID = r.id
WHERE l.reeksID = ?
ORDER BY l.finishTime";
$statement = $conn->prepare($sql);
$statement->bind_param('s', $reeksID);
$statement->execute();
$result = $statement->get_result();

$html = '<div><table id="example" class="table table-striped" style="width:100%">
<thead>
<tr>
<th>QR-code</th>
<th>Gebruiker</th>
<th>Starttijd</th>
<th>Eindtijd</th>
<th>Gelopen tijd</th>
<th>Plaats</th>
</tr>
</thead>
<tbody>';

$x = 0;
while ($row = $result->fetch_assoc()) {
   $x ++;
    $startAtTime = strtotime($row['startAt']);
    $finishTimeTime = strtotime($row['finishTime']);
    
    $tijdInSec = $finishTimeTime - $startAtTime;
    
    $uren = floor($tijdInSec / 3600);
    $minuten = floor(($tijdInSec % 3600) / 60);
    $seconden = $tijdInSec % 60;
    $duration = $uren . ':' . $minuten . ':' . $seconden;

    $html .= '<tr><td><img src="https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=/tijd-update?id=' . $row['id'] . '&color=566a7f&margin=0" style="width: 100px; height: 100px; margin-right: 5px; display: block; margin-bottom: 5px;"><a target="_blank" href="/crossQR/includes/tijd-update.php?id=' . $row['id'] . '">Link</a></td><td>' . $row['firstname'] . ' ' . $row['lastname'] . '</td><td style="margin-right: 100px;">'. $row['startAt'] .'</td><td>'. $row['finishTime'] .'</td><td>' . $duration . '</td><td>' . $x . '</td></tr>';
}

$html .= '</tbody></table></div>';



$response[0] = $html;
echo json_encode($response);

