<?php
include './dbh.inc.php';

if (isset($_GET['id'])) {
    $loperID = $_GET['id'];

    $sql = "SELECT * FROM `lopers` WHERE `id` = ?";
    $statement = $conn->prepare($sql);
    $statement->bind_param('i', $loperID);
    $statement->execute();
    $result = $statement->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $loperData = array(
            'firstname' => $row['firstname'],
            'lastname' => $row['lastname'],
            'gender' => $row['gender'],
            'birthdate' => $row['birthdate'],
            'schoolID' => $row['schoolID'],
            'klasID' => $row['klasID'],
            'reeksID' => $row['reeksID']
        );
        $statement->close();
        $conn->close();
        echo json_encode($loperData);
    } 
}
?>
