<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <title>Cross der jongeren</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="./js/loperinsert.js"> </script>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            padding: 2rem;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }

        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }

        .form-label {
            font-weight: bold;
        }

        .form-control {
            border-radius: 8px;
        }

        .alert {
            border-radius: 8px;
        }

        .container {
            margin-top: 50px;
        }

        .card-header {
            background-color: #f1f1f1;
            border-radius: 10px;
            padding: 10px;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <?php include './header.php'; ?>

    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-6 mx-auto">
                <div class="card">
                    <h4 class="mb-4 text-primary text-center">Registreer Loper</h4>
                    <div class="row">
                        <!-- Formulier voor individuele invoer -->
                        <div class="col-6 mb-3">
                            <label class="form-label">Voornaam</label>
                            <input type="text" id="firstname" class="form-control" placeholder="Voornaam">
                        </div>
                        <div class="col-6 mb-3">
                            <label class="form-label">Achternaam</label>
                            <input type="text" id="lastname" class="form-control" placeholder="Achternaam">
                        </div>
                        <div class="col-6 mb-3">
                            <label class="form-label">Geslacht</label>
                            <select id="gender" class="form-control">
                                <option value="" disabled selected>Kies een optie</option>
                                <option value="man">Man</option>
                                <option value="vrouw">Vrouw</option>
                            </select>
                        </div>
                        <div class="col-6 mb-3">
                            <label class="form-label">Geboortedatum</label>
                            <input type="date" id="birthdate" class="form-control">
                        </div>
                        <div class="col-6 mb-3">
                            <label class="form-label">School</label>
                            <select id="schoolID" class="form-control" onchange="toggleKlasVisibility()">
                                <option value="schoolID" disabled selected>School</option>
                                <?php
                                $sql = "SELECT * FROM `school` ORDER BY `name` DESC";
                                $statement = $conn->prepare($sql);
                                $results = $statement->execute();
                                $results = $statement->get_result();
                                while ($row = $results->fetch_assoc()) {
                                    echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-6 mb-3" id="klasContainer">
                            <label class="form-label">Klas</label>
                            <select id="klasID" class="form-control">
                                <option value="klasID" disabled selected>Klas</option>
                                <?php
                                $sql = "SELECT * FROM `klas` ORDER BY `name` DESC";
                                $statement = $conn->prepare($sql);
                                $results = $statement->execute();
                                $results = $statement->get_result();
                                while ($row = $results->fetch_assoc()) {
                                    echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-6 mb-3">
                            <label class="form-label">Reeks</label>
                            <select id="reeksID" class="form-control">
                                <option value="reeksID" disabled selected>Reeks</option>
                                <?php
                                $sql = "SELECT * FROM `reeksen` ORDER BY `reeks` DESC";
                                $statement = $conn->prepare($sql);
                                $results = $statement->execute();
                                $results = $statement->get_result();
                                while ($row = $results->fetch_assoc()) {
                                    echo '<option value="' . $row['id'] . '">' . $row['reeks'] . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <!-- Knop om individuele loper in te voegen -->
                    <div class="col-12">
                        <button class="btn btn-primary w-100 mt-3" onclick="insertLoper()">Registreer leerling</button>
                        <p class="alert alert-danger mt-3" id="errorMessage" style="display: none;">Niet alle velden zijn ingevuld</p>
                        <p class="alert alert-success mt-3" id="succesMessage" style="display: none;">Gebruiker toegevoegd</p>
                    </div>
                </div>
                <div class="card mt-5">
                    <h4 class="mb-4 text-primary text-center">Voeg school toe</h4>
                    <div class="form-group">
                        <label for="schoolName" class="form-label">Schoolnaam</label>
                        <input type="text" id="schoolName" name="schoolName" class="form-control" placeholder="Voer de schoolnaam in" required>
                    </div>
                    <div class="col-12 mt-3">
                        <div id="succesMessageSchool" class="alert alert-success mt-3 text-center" style="display: none;">
                            School succesvol toegevoegd!
                        </div>
                        <button type="submit" onclick="insertSchool()" class="btn btn-primary w-100">Voeg Klas Toe</button>
                    </div>
                </div>
                <!-- Klas Toevoegen Formulier -->
                <div class="card mt-5">
                    <h4 class="mb-4 text-primary text-center">Voeg klas toe</h4>
                    <div class="form-group">
                        <label for="klasName" class="form-label">Klasnaam</label>
                        <input type="text" id="klasName" name="klasName" class="form-control" placeholder="Voer de klasnaam in" required>
                    </div>
                    <div class="col-12 mt-3">
                        <div id="succesMessageReeks" class="alert alert-success mt-3 text-center" style="display: none;">
                            Reeks succesvol toegevoegd!
                        </div>
                        <button type="submit" onclick="insertKlas()" class="btn btn-primary w-100">Voeg Klas Toe</button>
                    </div>
                </div>
                <!-- Excel Bestand Uploaden -->
                <div class="card mt-5">
                    <h4 class="mb-4 text-primary text-center">Upload Excel Bestand</h4>
                    <form id="excelForm" action="upload_excel.php" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="excelFile" class="form-label">Kies Excel bestand</label>
                            <input type="file" id="excelFile" name="excelFile" class="form-control" accept=".xlsx, .xls" required>
                        </div>
                        <div class="col-12 mt-3">
                            <button type="submit" class="btn btn-success w-100">Upload en Verwerk Excel</button>
                        </div>
                    </form>
                    <p class="alert alert-danger mt-3" id="uploadErrorMessage" style="display: none;">Er is een probleem met het bestand</p>
                    <p class="alert alert-success mt-3" id="uploadSuccessMessage" style="display: none;">Bestand succesvol geüpload</p>
                </div>



            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>