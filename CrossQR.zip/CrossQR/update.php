<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cross der jongeren</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="./js/lopers-update.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .card {
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
    </style>
</head>

<body>
    <?php include './header.php'; ?>



    <div class="container mt-5">
        <div class="col-lg-8 mx-auto">
            <div class="card p-4">
                <h4 class="mb-3 text-primary">Update Loper</h4>

                <label class="form-label">Loper</label>
                <select id="loperID" class="form-control mb-3" onchange="fetchLoperData()">
                    <option value="loperID" disabled selected>Selecteer een loper</option>
                    <?php
                    $sql = "SELECT * FROM `lopers` ORDER BY `lastname` DESC";
                    $statement = $conn->prepare($sql);
                    $results = $statement->execute();
                    $results = $statement->get_result();
                    while ($row = $results->fetch_assoc()) {
                        echo '<option value="' . $row['id'] . '">' . $row['firstname'] . ' ' . $row['lastname'] . '</option>';
                    }
                    ?>
                </select>

                <div class="row">
                    <div class="col-6 mb-3">
                        <label class="form-label">Voornaam</label>
                        <input type="text" id="nieuweFirstname" class="form-control" placeholder="Voornaam">
                    </div>
                    <div class="col-6 mb-3">
                        <label class="form-label">Achternaam</label>
                        <input type="text" id="nieuweLastname" class="form-control" placeholder="Achternaam">
                    </div>
                    <div class="col-6 mb-3">
                        <label class="form-label">Geslacht</label>
                        <select id="nieuweGender" class="form-control">
                            <option value="" disabled selected>Kies een optie</option>
                            <option value="man">Man</option>
                            <option value="vrouw">Vrouw</option>
                        </select>
                    </div>
                    <div class="col-6 mb-3">
                        <label class="form-label">Geboortedatum</label>
                        <input type="date" id="nieuweBirthdate" class="form-control">
                    </div>
                    <div class="col-6 mb-3">
                        <label class="form-label">School</label>
                        <select id="schoolID" class="form-control">
                            <option value="schoolID" disabled selected>School</option>
                            <?php
                            $sql = "SELECT * FROM `school` ORDER BY `name` DESC";
                            $statement = $conn->prepare($sql);
                            $results = $statement->execute();
                            $results = $statement->get_result();
                            while ($row = $results->fetch_assoc()) {
                                echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-6 mb-3">
                        <label class="form-label">Klas</label>
                        <select id="klasID" class="form-control">
                            <option value="klasID" disabled selected>Klas</option>
                            <?php
                            $sql = "SELECT * FROM `klas` ORDER BY `name` DESC";
                            $statement = $conn->prepare($sql);
                            $results = $statement->execute();
                            $results = $statement->get_result();
                            while ($row = $results->fetch_assoc()) {
                                echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-6 mb-3">
                        <label class="form-label">Reeks</label>
                        <select id="reeksID" class="form-control">
                            <option value="reeksID" disabled selected>Reeks</option>
                            <?php
                            $sql = "SELECT * FROM `reeksen` ORDER BY `reeks` DESC";
                            $statement = $conn->prepare($sql);
                            $results = $statement->execute();
                            $results = $statement->get_result();
                            while ($row = $results->fetch_assoc()) {
                                echo '<option value="' . $row['id'] . '">' . $row['reeks'] . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div id="succesMessageLoper" class="alert alert-success mt-3 text-center" style="display: none;">
                    Loper succesvol geüpdatet!
                </div>
                <button class="btn btn-primary w-100 mt-3" onclick="updateLopers()">Update leerling</button>

            </div>
        </div>
    </div>
    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-6 mx-auto">
                <div class="card p-4">
                    <h4 class="mb-3 text-primary">Update Reeks</h4>
                    <div class="row">
                        <div class="col-6 mb-3">
                            <label class="form-label">Reeks</label>
                            <select id="reeksID" class="form-control">
                                <option value="reeksID" disabled selected>Reeks</option>
                                <?php
                                $sql = "SELECT * FROM `reeksen` ORDER BY `reeks` DESC";
                                $statement = $conn->prepare($sql);
                                $results = $statement->execute();
                                $results = $statement->get_result();
                                while ($row = $results->fetch_assoc()) {
                                    echo '<option value="' . $row['id'] . '">' . $row['reeks'] . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-6 mb-3">
                            <label class="form-label">Nieuwe reeks</label>
                            <input type="text" id="nieuweReeks" class="form-control" placeholder="Nieuwe reeks naam">
                        </div>
                    </div>
                    <button class="btn btn-primary w-100" onclick="updateReeks()">Update reeks</button>
                    <div id="succesMessageReeks" class="alert alert-success mt-3 text-center" style="display: none;">
                        Reeks succesvol geüpdatet!
                    </div>
                </div>
            </div>
        </div>
    </div>  

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>