<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">

  <title>Cross der jongeren ADMIN</title>
</head>

<body>
  <?php
  include './header.php';
  ?>
  <div class="container" id="adminPage">
    <h1>Welcome <?php echo $_SESSION['user'] ?></h1>

    <!-- 
       Stap 1: Spuit uw oren uit! 
       Stap 2: Voorzie een input waar de admin nieuwe gebruikers kan aanmeken.
                - id
                - voornaam
                - achternaam
                - geslacht
                - klasId
                - schoolId
                - geboortedatum
                - eindtijd (Y-m-d H:i:s) - gaat automatisch geupdate worden bij het scanne van de QR-code
            Volgende tabellen
            klas met id, naam, begintijd (Y-m-d H:i:s)
            school met id, naam
        Stap 3: Overzicht van alle reeksen (geboeertejaar) met de gebruikers die deelnemen (en hun klas)
        Stap 4: Toon QR-code per gebruiker (google api) = IMAGE("https://crossderjongere/includes/update?id='.$row['id'])
        Stap 5: Qcode kunnen inscannen
        Stap 6: eindtijd updaten (door de link van de QR-code)
            -->
  </div>
</body>

</html>